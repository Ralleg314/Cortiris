package com.everis.cdac.ws;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.LoggingFilter;


public class WSPostLanguageDetection {

	private static Logger log = Logger.getLogger(WSPostLanguageDetection.class);
	
	// Constants error handlers
	private static final String FORBIDDEN = "Forbidden";
	private static final String INVALID_RESOURCE = "Missing Authentication Token";
	private static final String EXECUTION_CODE_WAIT = "taskWaiting";
	
	private static final String MESSAGE_FORBIDDEN = "Access denied, wrong api-key or incorrect path (you should work in /dev/ path)";
	private static final String MESSAGE_INVALID_RESOURCE = "Access denied, you have to work on the resource sentiment or language";
	private static final String MESSAGE_NOWAIT = "Sorry the request came back before it was finished processing, use WAIT_TO_FINISH = '?wait=true'";

	public static void main(String[] args) throws IOException, JSONException {
		
		if(args == null || args.length != 3){
			
			System.out.println("inputs = \n 1- url_endpoint: everisMoriarty langyage detector service endpoint, "
					+ "\n 2- auth_token: autorization token, \n 3- textIn: input text to identify its language, "
					);
		}else{
			
			// everisMoriarty sentiment service endpoint
			String serviceURL = args[0];
			// autorization token
			String authToken = args[1];
			// input text to classify its sentiment
			String textIn = args[2];
			
			try{
				
				// send request and return language result
				String language = sendFileJSON(serviceURL, authToken, textIn);
				log.info("input text = "+textIn + " , language = " + language);
				
			} catch(Exception ex){
				
				log.error("error while requesting everisMoriarty web service api");
				log.error(ex.getMessage());
			}
			
		}
	}
	
	private static String sendFileJSON(String URL_SERVICE, String authToken, String textIn) throws IOException, JSONException{

        ClientConfig config = new DefaultClientConfig();
        Client client = Client.create(config);
        client.addFilter(new LoggingFilter());
        WebResource service = client.resource(URL_SERVICE);
        JSONObject data_file = new JSONObject();
     
        
        data_file.put("textIn", textIn);
        
        // requesting everisMoriarty endpoint
        ClientResponse client_response = service.header("x-api-key", authToken).accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, data_file);

        InputStream input = client_response.getEntityInputStream();
		String theString = IOUtils.toString(input, "UTF-8"); 
		
		Gson gson = new Gson();
		Map<String, Object> javaRootMapObject = gson.fromJson(theString, Map.class);
		log.debug(String.format("response message [%s]", javaRootMapObject.get("message")));
		
		// get response message
		String message = (String) javaRootMapObject.get("message");
		log.debug(String.format("response message [%s]", message));
		
		if(message.equals(FORBIDDEN)){
			log.error(MESSAGE_FORBIDDEN);
		
		} else if(message.equals(INVALID_RESOURCE)){
			log.error(MESSAGE_INVALID_RESOURCE);
		} else if(message.isEmpty()){
			
			Map<String, Object> statusObj = (Map<String, Object>) javaRootMapObject.get("status");
			String status = (String) statusObj.get("executionStatusCode");
			if(status.equals(EXECUTION_CODE_WAIT)){
				log.error(MESSAGE_NOWAIT);
			}
			
		}
				
		Map<String, Object> results = (Map<String, Object>) javaRootMapObject.get("results");
		// get response language
		String language = (String) results.get("language");
		
		IOUtils.closeQuietly(input);
        client.destroy();
        
        return language;
    }

}
