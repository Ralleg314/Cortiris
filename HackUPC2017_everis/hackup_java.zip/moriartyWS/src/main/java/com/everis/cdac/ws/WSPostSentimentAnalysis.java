package com.everis.cdac.ws;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.LoggingFilter;


public class WSPostSentimentAnalysis {

	private static Logger log = Logger.getLogger(WSPostSentimentAnalysis.class);
	
	// Constants error handlers
	private static final String FORBIDDEN = "Forbidden";
	private static final String INVALID_RESOURCE = "Missing Authentication Token";
	private static final String EXECUTION_CODE_WAIT = "taskWaiting";
	
	private static final String MESSAGE_FORBIDDEN = "Access denied, wrong api-key or incorrect path (you should work in /dev/ path)";
	private static final String MESSAGE_INVALID_RESOURCE = "Access denied, you have to work on the resource sentiment or language";
	private static final String MESSAGE_NOWAIT = "Sorry the request came back before it was finished processing, use WAIT_TO_FINISH = '?wait=true'";
	
	public static void main(String[] args) throws IOException, JSONException {
		
		if(args == null || args.length != 4){
			
			System.out.println("inputs = \n 1- url_endpoint: everisMoriarty sentiment service endpoint, "
					+ "\n 2- auth_token: autorization token, \n 3- textIn: input text to classify its sentiment, "
					+ "\n 4- language: input text language");
		}else{
			
			// everisMoriarty sentiment service endpoint
			String serviceURL = args[0];
			// autorization token
			String authToken = args[1];
			// input text to classify its sentiment
			String textIn = args[2];
			// input text language (Spanish or English)
			String language = args[3];
						
			try{
				
				// send request and return sentiment result
				String sentiment = sendFileJSON(serviceURL, authToken, textIn, language);
				log.info("input text = "+textIn + " , sentiment = " + sentiment);
				
			} catch(Exception ex){
				
				log.error("error while requesting everisMoriarty web service api");
				log.error(ex.getMessage());
			}
			
		}
	}
	
	private static String sendFileJSON(String serviceURL, String authToken, String textIn, String language) 
								throws IOException, JSONException{

        ClientConfig config = new DefaultClientConfig();
        Client client = Client.create(config);
        client.addFilter(new LoggingFilter());
        WebResource service = client.resource(serviceURL);
        JSONObject data_file = new JSONObject();
     
        data_file.put("textIn", textIn);
        data_file.put("language", language);
        
        // invocamos el flujo de clasificacion de eM mediante web service
        ClientResponse client_response = service.header("x-api-key", authToken).accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, data_file);

        InputStream input = client_response.getEntityInputStream();
		String theString = IOUtils.toString(input, "UTF-8"); 
		
		Gson gson = new Gson();
		Map<String, Object> javaRootMapObject = gson.fromJson(theString, Map.class);
		log.debug(String.format("response message [%s]", javaRootMapObject.get("message")));
		
		// get response message
		String message = (String) javaRootMapObject.get("message");
		log.debug(String.format("response message [%s]", message));
		
		if(message.equals(FORBIDDEN)){
			log.error(MESSAGE_FORBIDDEN);
		
		} else if(message.equals(INVALID_RESOURCE)){
			log.error(MESSAGE_INVALID_RESOURCE);
		} else if(message.isEmpty()){
			
			Map<String, Object> statusObj = (Map<String, Object>) javaRootMapObject.get("status");
			String status = (String) statusObj.get("executionStatusCode");
			if(status.equals(EXECUTION_CODE_WAIT)){
				log.error(MESSAGE_NOWAIT);
			}
			
		}

		
		Map<String, Object> results = (Map<String, Object>) javaRootMapObject.get("results");
		// get sentiment response
		String prediction = (String) results.get("prediction");
		
		IOUtils.closeQuietly(input);
        client.destroy();
        
        return prediction;

    }

}
